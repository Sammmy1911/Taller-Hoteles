import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class User {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column({unique: true})
    email: string;

    @Column()
    password: string; 

    @Column()
    name: string;

    @Column({nullable: true})
    phone: string;

    @Column('varchar', {array: true, default:['user']})
    roles:string;

    @Column({type: 'timestamp', default: () => 'CURRENT_TIMESTAMP'})
    createAt: Date; 
}
